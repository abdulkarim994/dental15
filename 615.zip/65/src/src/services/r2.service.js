import { getSbToken } from './supabase.service'
import { supabase } from './supabase.service'

const R2_WORKER = import.meta.env.VITE_R2_WORKER

async function refreshToken() {
  try {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session?.access_token) {
      const { data: refreshData } = await supabase.auth.refreshSession()
      return refreshData?.session?.access_token || getSbToken()
    }
    // Proactively refresh if token expires within 5 minutes
    try {
      const payload = JSON.parse(atob(session.access_token.split('.')[1]))
      if (payload.exp && (payload.exp * 1000 - Date.now() < 300000)) {
        const { data: refreshData } = await supabase.auth.refreshSession()
        return refreshData?.session?.access_token || session.access_token
      }
    } catch { /* token parse failed, use current */ }
    return session.access_token
  } catch {
    // Session retrieval failed — try explicit refresh before falling back
    try {
      const { data: refreshData } = await supabase.auth.refreshSession()
      if (refreshData?.session?.access_token) return refreshData.session.access_token
    } catch { /* refresh also failed */ }
    return getSbToken()
  }
}

export function r2Url(key) {
  if (!R2_WORKER) return ''
  return `${R2_WORKER}/image/${encodeURIComponent(key)}`
}

export function r2AuthHeaders() {
  return { 'Authorization': `Bearer ${getSbToken()}` }
}

/**
 * Fetch an image using Authorization header (more secure than URL token).
 * Returns a blob URL suitable for <img src>. Falls back to direct URL.
 */
export async function fetchImageSecure(key) {
  if (!R2_WORKER) return null
  try {
    const token = await refreshToken()
    const res = await fetch(`${R2_WORKER}/image/${encodeURIComponent(key)}`, {
      headers: { 'Authorization': `Bearer ${token}` },
    })
    if (!res.ok) return null
    const blob = await res.blob()
    return URL.createObjectURL(blob)
  } catch {
    return null
  }
}

const UPLOAD_TIMEOUT = 120000
const UPLOAD_MAX_RETRIES = 2

export async function uploadImage(file, key, patientName, fileName) {
  let lastError = null
  for (let attempt = 0; attempt <= UPLOAD_MAX_RETRIES; attempt++) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), UPLOAD_TIMEOUT)

    try {
      const token = await refreshToken()
      const params = new URLSearchParams({ key: key || '' })
      const res = await fetch(`${R2_WORKER}/upload?${params}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': file.type || 'image/jpeg',
          'X-Patient-Name': encodeURIComponent(patientName || ''),
          'X-File-Name': encodeURIComponent(fileName || ''),
        },
        body: file,
        signal: controller.signal,
      })

      clearTimeout(timer)
      if (!res.ok) throw new Error(`Upload failed: ${res.status}`)
      return await res.json()
    } catch (e) {
      clearTimeout(timer)
      lastError = e
      if (attempt < UPLOAD_MAX_RETRIES) {
        await new Promise(r => setTimeout(r, 1000 * (attempt + 1)))
      }
    }
  }
  throw lastError
}

export async function deleteImage(key) {
  const token = await refreshToken()
  const res = await fetch(`${R2_WORKER}/image/${encodeURIComponent(key)}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${token}` },
  })
  if (!res.ok) throw new Error(`Delete failed: ${res.status}`)
}

export async function compressImage(file, maxWidth = 1200, quality = 0.8) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    const url = URL.createObjectURL(file)
    img.onload = () => {
      URL.revokeObjectURL(url)
      const canvas = document.createElement('canvas')
      let { width, height } = img
      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width)
        width = maxWidth
      }
      if (height > maxWidth) {
        width = Math.round((width * maxWidth) / height)
        height = maxWidth
      }
      canvas.width = width
      canvas.height = height
      const ctx = canvas.getContext('2d')
      ctx.drawImage(img, 0, 0, width, height)
      canvas.toBlob(blob => {
        if (blob) resolve(blob)
        else reject(new Error('Compression failed'))
      }, 'image/jpeg', quality)
    }
    img.onerror = () => {
      URL.revokeObjectURL(url)
      reject(new Error('Image load failed'))
    }
    img.src = url
  })
}

export function createThumbnail(file, size = 150) {
  return compressImage(file, size, 0.6)
}
